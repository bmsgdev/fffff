<template>
<!-- Modal - Formulaire d'ajout -->
<div class="modal-content relative bg-white p-8 rounded-lg shadow-lg max-w-lg mx-auto transition-all ease-in-out duration-300 transform scale-95 hover:scale-100"
>
  <!-- Close Button -->
  <span class="absolute top-4 right-4 text-2xl text-gray-500 cursor-pointer hover:text-red-500 transition-colors duration-200"  @click="store.showForm=false" >&times;</span>
  
  <!-- Form Title -->
  <h2 class="text-3xl font-semibold text-blue-600 text-center mb-6">
    {{ store.isEditing ? "Modifier un étudiant" : "Ajouter un étudiant" }}
  </h2>

  <!-- Form Fields -->
  <div class="space-y-4">
    <input v-model="store.newStudent.name" placeholder="Nom" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
    <input v-model="store.newStudent.age" type="number" placeholder="Âge" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
    <input v-model="store.newStudent.filiere" placeholder="Filière" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
    
    <!-- Sexe Select -->
    <select v-model="store.newStudent.sexe" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
      <option value="">-- Sexe --</option>
      <option value="Masculin">Masculin</option>
      <option value="Féminin">Féminin</option>
    </select>

    <input v-model="store.newStudent.nationalite" placeholder="Nationalité" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
  </div>

  <!-- Action Buttons -->
<div class="mt-6 flex justify-end space-x-4">
    <button @click="store.isEditing ? store.updateStudent() : store.addStudent()" class="py-2 px-6 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
        {{ store.isEditing ? "Mettre à jour" : "Ajouter" }}
    </button>
    
    <!-- Cancel Button for Editing -->
    <button v-if="store.isEditing" @click="store.cancelEdit()" class="py-2 px-6 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition duration-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50">
        Annuler
    </button>
</div>
</div>

</template>
<script setup>
import { studentStore } from "@/stores/studentStore";
const store = studentStore();
</script>
