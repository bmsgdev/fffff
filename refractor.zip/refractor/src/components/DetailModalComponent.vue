<template>
  <div
    class="modal-content relative bg-white p-8 rounded-lg shadow-lg max-w-lg mx-auto transition-all ease-in-out duration-300 transform scale-95 hover:scale-100"
  >
    <!-- Close Button -->
    <span
      class="absolute top-4 right-4 text-2xl text-gray-500 cursor-pointer hover:text-red-500 transition-colors duration-200"
      @click="store.selectedStudent = null"
      >&times;</span
    >

    <!-- Modal Header -->
    <h2 class="text-3xl font-semibold text-gray-900 mb-4">
      Détails de l'étudiant
    </h2>

    <!-- Modal Content -->
    <div class="space-y-4">
      <p class="text-lg text-gray-700">
        <strong class="font-semibold text-blue-600">Nom :</strong>
        {{ store.selectedStudent.name }}
      </p>
      <p class="text-lg text-gray-700">
        <strong class="font-semibold text-blue-600">Âge :</strong>
        {{ store.selectedStudent.age }} ans
      </p>
      <p class="text-lg text-gray-700">
        <strong class="font-semibold text-blue-600">Filière :</strong>
        {{ store.selectedStudent.filiere }}
      </p>
      <p class="text-lg text-gray-700">
        <strong class="font-semibold text-blue-600">Sexe :</strong>
        {{ store.selectedStudent.sexe }}
      </p>
      <p class="text-lg text-gray-700">
        <strong class="font-semibold text-blue-600">Nationalité :</strong>
        {{ store.selectedStudent.nationalite }}
      </p>
    </div>

    <!-- Footer with buttons -->
    <div class="mt-6 flex justify-end gap-4">
      <button
       @click="store.selectedStudent = null"
        class="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
      >
        Fermer
      </button>
    </div>
  </div>
</template>
<script setup>
import { studentStore } from "@/stores/studentStore";
const store = studentStore();
</script>
