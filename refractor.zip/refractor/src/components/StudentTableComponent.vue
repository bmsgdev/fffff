<template>
  <div v-if="store.students.length" class="p-6">
    <h2 class="text-3xl font-semibold text-gray-800 mb-4">
      Liste des étudiants ({{ store.students.length }})
    </h2>

    <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow-lg">
      <thead class="bg-gray-100 text-gray-600 uppercase text-sm">
        <tr>
          <th class="px-6 py-3 text-left">ID</th>
          <th class="px-6 py-3 text-left">Nom</th>
          <th class="px-6 py-3 text-left">Âge</th>
          <th class="px-6 py-3 text-left">Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(student, index) in store.students" :key="index" @click="store.showStudentDetails(student)" class="cursor-pointer hover:bg-gray-50">
          <td class="px-6 py-4 text-sm text-gray-800">{{ index + 1 }}</td>
          <td class="px-6 py-4 text-sm text-gray-800">{{ student.name }}</td>
          <td class="px-6 py-4 text-sm text-gray-800">{{ student.age }}</td>
          <td class="px-6 py-4 text-sm text-gray-800 flex gap-2">
            <button
              class="bg-yellow-500 hover:bg-yellow-600 text-white py-1 px-3 rounded-lg transition-all duration-200"
              @click.stop="store.editStudent(index);"
            >
              ✏️ Modifier
            </button>
            <button
              class="bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded-lg transition-all duration-200"
              @click.stop="store.deleteStudent(index);"
            >
              🗑️ Supprimer
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <p v-else class="text-lg text-gray-500 mt-4">Aucun étudiant trouvé.</p>
</template>
<script setup>
import { studentStore } from "@/stores/studentStore";
import {onMounted } from "vue";
const store = studentStore();
// Charger les étudiants du localStorage
onMounted(() => {
  const savedStudents = JSON.parse(localStorage.getItem("students"));
  if (savedStudents) store.students = savedStudents;
});
</script>
