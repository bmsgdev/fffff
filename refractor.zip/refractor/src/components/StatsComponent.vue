<template>
   <div class="stats-container bg-white p-8 rounded-xl shadow-xl max-w-4xl mx-auto mt-8 space-y-6 transition-transform transform hover:scale-100">
  <!-- Header -->
  <h2 class="text-3xl font-semibold text-blue-600 flex items-center gap-2">
    <span>📊</span> Statistiques
  </h2>
  
  <!-- Statistiques Content -->
  <div class="space-y-4 text-lg text-gray-700">
    <p><strong class="font-semibold text-blue-600">Nombre total d'étudiants :</strong> <span class="text-gray-900">{{ store.students.length }}</span></p>
    <p><strong class="font-semibold text-blue-600">Moyenne d'âge :</strong> <span class="text-gray-900">{{ store.averageAge }}</span> ans</p>
    <p>
      <strong class="font-semibold text-blue-600">Mineurs :</strong> 
      <span class="text-gray-900">{{ store.minorCount }}</span> | 
      <strong class="font-semibold text-blue-600">Majeurs :</strong> 
      <span class="text-gray-900">{{ store.majorCount }}</span>
    </p>
  </div>
</div>

</template>
<script setup>
import {studentStore} from '@/stores/studentStore';
const store = studentStore();
</script>