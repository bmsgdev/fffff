<template>
<div>
  <h1 class="text-center mt-2 font-bold">📚 Gestion des Étudiants</h1>
  <StatsComponent />
  <!-- Bouton "Ajouter" ajusté -->
  <button
    @click="store.showForm = true"
    class="ml-4 p-4 text-lg font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 rounded-full shadow-md transition-all duration-300 ease-in-out transform hover:scale-105"
  >
    +
  </button>
  <!-- Modal pour le formulaire étudiant avec fond flouté -->
  <div v-if="store.showForm" class="fixed inset-0 bg-transparent bg-opacity-25 backdrop-blur-sm flex justify-center items-center z-50">
    <StudentFormaComponent />
  </div>
  <StudentTableComponent />
  <!-- Modal des détails d'un étudiant avec fond flouté -->
  <div
    v-if="store.selectedStudent"
    class="fixed inset-0 bg-transparent bg-opacity-25 backdrop-blur-sm flex justify-center items-center z-50"
  >
    <DetailModalComponent />
  </div>
</div>

</template>

<script setup>
// Liste des étudiants
import {defineAsyncComponent } from 'vue';
import { studentStore } from "@/stores/studentStore";
const StudentFormaComponent = defineAsyncComponent(() => import("./components/StudentFormaComponent.vue"));
const StudentTableComponent = defineAsyncComponent(() => import("./components/StudentTableComponent.vue"));
const DetailModalComponent = defineAsyncComponent(() => import("./components/DetailModalComponent.vue"));
const StatsComponent = defineAsyncComponent(() => import("./components/StatsComponent.vue"));
const store = studentStore();
</script>
