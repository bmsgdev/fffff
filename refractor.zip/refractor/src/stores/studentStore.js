import { defineStore } from 'pinia';
/**
 * Store Vuex pour la gestion des étudiants.
 * 
 * @typedef {Object} Student
 * @property {string} name - Le nom de l'étudiant.
 * @property {string} age - L'âge de l'étudiant.
 * @property {string} filiere - La filière de l'étudiant.
 * @property {string} sexe - Le sexe de l'étudiant.
 * @property {string} nationalite - La nationalité de l'étudiant.
 * 
 * @property {Student[]} students - Liste des étudiants.
 * @property {Student} newStudent - Nouveau étudiant à ajouter ou à modifier.
 * @property {boolean} isEditing - Indique si un étudiant est en cours de modification.
 * @property {number|null} editIndex - Index de l'étudiant en cours de modification.
 * @property {Student|null} selectedStudent - Étudiant sélectionné pour afficher les détails.
 * @property {boolean} showForm - Indique si le formulaire d'ajout/modification est affiché.
 * 
 * @method saveStudents - Sauvegarde la liste des étudiants dans le localStorage.
 * @method addStudent - Ajoute un nouvel étudiant à la liste.
 * @method editStudent - Prépare le formulaire pour la modification d'un étudiant.
 * @method updateStudent - Met à jour les informations d'un étudiant.
 * @method deleteStudent - Supprime un étudiant de la liste.
 * @method cancelEdit - Annule la modification en cours.
 * @method resetForm - Réinitialise le formulaire d'ajout/modification.
 * @method showStudentDetails - Affiche les détails d'un étudiant sélectionné.
 * 
 * @getter averageAge - Calcule l'âge moyen des étudiants.
 * @getter minorCount - Compte le nombre d'étudiants mineurs.
 * @getter majorCount - Compte le nombre d'étudiants majeurs.
 */
export const studentStore = defineStore('student', {
    state: () => ({
      students: [],
      newStudent: { name: "", age: "", filiere: "", sexe: "", nationalite: "" },
      isEditing: false,
      editIndex: null,
      selectedStudent: null,
      showForm: false,
    }),
    actions: {
      saveStudents() {
        localStorage.setItem("students", JSON.stringify(this.students));
      },
      addStudent() {
        if (this.newStudent.name && this.newStudent.age && this.newStudent.filiere && this.newStudent.sexe && this.newStudent.nationalite) {
          this.students.push({ ...this.newStudent });
          this.showForm= false;
          this.saveStudents();
          this.resetForm();
        } else {
          alert("Veuillez remplir tous les champs !");
        }
      },
      editStudent(index) {
        this.newStudent = { ...this.students[index] };
        this.editIndex = index;
        this.isEditing = true;
        this.showForm= true;
      },
      updateStudent() {
        if (this.newStudent.name && this.newStudent.age) {
          this.students[this.editIndex] = { ...this.newStudent };
          this.showForm= false;
          this.saveStudents();
          this.cancelEdit();
        } else {
          alert("Veuillez remplir tous les champs !");
        }
      },
      deleteStudent(index) {
        if (confirm("Voulez-vous vraiment supprimer cet étudiant ?")) {
          this.students.splice(index, 1);
          this.saveStudents();
        }
      },
      cancelEdit() {
        this.resetForm();
        this.isEditing = false;
        this.showForm=false;
      },
      resetForm() {
        this.newStudent = { name: "", age: "", filiere: "", sexe: "", nationalite: "" };
        this.editIndex = null;
      },
      showStudentDetails(student) {
        this.selectedStudent = student;
      }
    },
    getters: {
      averageAge: (state) => {
        if (state.students.length === 0) return 0;
        return (state.students.reduce((sum, student) => sum + Number(student.age), 0) / state.students.length).toFixed(1);
      },
      minorCount: (state) => state.students.filter(student => student.age < 18).length,
      majorCount: (state) => state.students.filter(student => student.age >= 18).length
    }
  });